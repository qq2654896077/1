module.exports = {
  root: true,
  extends: ['@antfu'],
}
